import os
import multiprocessing
from threading import Timer
import psycopg2
from psycopg2.extras import RealDictCursor
from flask import Flask, render_template, request, jsonify
from datetime import datetime, date

app = Flask(__name__, template_folder='templates')

# Paste your full Supabase URI string here
SUPABASE_URI = "postgresql://postgres.lhxpogmftjcwpizztkfi:eALhNDE7ZFK8ewJW@aws-0-eu-north-1.pooler.supabase.com:6543/postgres"

def get_db_connection():
    conn = psycopg2.connect(SUPABASE_URI)
    # Autocommit removes the need to manually call conn.commit() after every change
    conn.autocommit = True 
    return conn

# --- Route 1: The Main Dashboard ---
@app.route('/')
def index():
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    
    cursor.execute('''
        SELECT jobs.*, customers.company_name 
        FROM jobs 
        LEFT JOIN customers ON jobs.customer_id = customers.id
        WHERE jobs.current_stage != 'paid'
    ''')
    jobs = cursor.fetchall()
    
    cursor.execute('SELECT * FROM customers ORDER BY company_name')
    customers = cursor.fetchall()
    
    cursor.close()
    conn.close()

    stages = ['booked in', 'on proof', 'approved', 'sent to print', 'printed', 'invoiced', 'paid']
    board_data = {stage: [] for stage in stages}
    
    today = date.today()

    for job in jobs:
        job_dict = dict(job)
        job_dict['urgency'] = 'normal'

        if job_dict.get('delivery_date') and job_dict['current_stage'] not in ['printed', 'invoiced', 'paid']:
            try:
                d_date = datetime.strptime(job_dict['delivery_date'], '%Y-%m-%d').date()
                delta = (d_date - today).days
                
                if delta < 0:
                    job_dict['urgency'] = 'overdue'
                elif delta <= 1:
                    job_dict['urgency'] = 'warning'
            except ValueError:
                pass

        current_stage = job_dict['current_stage']
        if current_stage in board_data:
            board_data[current_stage].append(job_dict)
            
    return render_template('index.html', board_data=board_data, stages=stages, customers=customers)

# --- Route 2: Update Stage (Drag and Drop) ---
@app.route('/update_stage', methods=['POST'])
def update_stage():
    data = request.get_json()
    job_number = data.get('job_number')
    new_stage = data.get('stage')

    if not job_number or not new_stage:
        return jsonify({'success': False, 'error': 'Missing data'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(
            'UPDATE jobs SET current_stage = %s WHERE job_number = %s',
            (new_stage, job_number)
        )
        cursor.execute(
            'INSERT INTO status_logs (job_number, stage) VALUES (%s, %s)',
            (job_number, new_stage)
        )
        success = True
    except Exception as e:
        success = False
        print(f"Database error: {e}")
    finally:
        cursor.close()
        conn.close()

    return jsonify({'success': success})

# --- Route 3: Add a New Job ---
@app.route('/add_job', methods=['POST'])
def add_job():
    data = request.get_json()
    job_number = data.get('job_number')
    customer_id = data.get('customer_id')
    title = data.get('title')
    finished_size = data.get('finished_size')
    paper_stock = data.get('paper_stock')
    delivery_date = data.get('delivery_date')
    date_received = data.get('date_received')
    quantity = data.get('quantity')
    ink = data.get('ink')
    finishing = data.get('finishing')
    price = data.get('price')

    customer_id = int(customer_id) if customer_id else None

    if not job_number or not title:
        return jsonify({'success': False, 'error': 'Job number and title are required.'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO jobs (
                job_number, customer_id, title, finished_size, paper_stock, 
                delivery_date, date_received, quantity, ink, finishing, price, current_stage
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'booked in')
        ''', (job_number, customer_id, title, finished_size, paper_stock, 
              delivery_date, date_received, quantity, ink, finishing, price))
        
        cursor.execute('INSERT INTO status_logs (job_number, stage) VALUES (%s, %s)', (job_number, 'booked in'))
        success = True
    except psycopg2.IntegrityError:
        return jsonify({'success': False, 'error': 'Job number already exists.'}), 400
    except Exception as e:
        success = False
        print(f"Database error: {e}")
    finally:
        cursor.close()
        conn.close()
    return jsonify({'success': success})


# --- Route 4: Edit an Existing Job ---
@app.route('/update_job', methods=['POST'])
def update_job():
    data = request.get_json()
    job_number = data.get('job_number')
    customer_id = data.get('customer_id')
    title = data.get('title')
    finished_size = data.get('finished_size')
    paper_stock = data.get('paper_stock')
    delivery_date = data.get('delivery_date')
    date_received = data.get('date_received')
    quantity = data.get('quantity')
    ink = data.get('ink')
    finishing = data.get('finishing')
    price = data.get('price')

    customer_id = int(customer_id) if customer_id else None

    if not job_number:
        return jsonify({'success': False, 'error': 'Job number missing.'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            UPDATE jobs 
            SET customer_id = %s, title = %s, finished_size = %s, paper_stock = %s, 
                delivery_date = %s, date_received = %s, quantity = %s, ink = %s, finishing = %s, price = %s
            WHERE job_number = %s
        ''', (customer_id, title, finished_size, paper_stock, 
              delivery_date, date_received, quantity, ink, finishing, price, job_number))
        success = True
    except Exception as e:
        success = False
        print(f"Database error: {e}")
    finally:
        cursor.close()
        conn.close()
    return jsonify({'success': success})

# --- Route 5: The Customers Page ---
@app.route('/customers')
def customers():
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    
    cursor.execute('SELECT * FROM customers ORDER BY company_name')
    all_customers = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template('customers.html', customers=all_customers)

# --- Route 6: Add a New Customer ---
@app.route('/add_customer', methods=['POST'])
def add_customer():
    data = request.get_json()
    
    company_name = data.get('company_name')
    contact_name = data.get('contact_name')
    primary_job_title = data.get('primary_job_title')
    email = data.get('email')
    primary_phone = data.get('primary_phone')
    
    secondary_contact_name = data.get('secondary_contact_name')
    secondary_job_title = data.get('secondary_job_title')
    secondary_email = data.get('secondary_email')
    secondary_phone = data.get('secondary_phone')

    if not company_name:
        return jsonify({'success': False, 'error': 'Company name is required.'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute('''
            INSERT INTO customers (
                company_name, contact_name, primary_job_title, email, primary_phone,
                secondary_contact_name, secondary_job_title, secondary_email, secondary_phone
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        ''', (company_name, contact_name, primary_job_title, email, primary_phone,
              secondary_contact_name, secondary_job_title, secondary_email, secondary_phone))
        success = True
    except Exception as e:
        success = False
        print(f"Database error: {e}")
    finally:
        cursor.close()
        conn.close()

    return jsonify({'success': success})

# --- Route 7: Client Profile Page ---
@app.route('/customer/<int:customer_id>')
def customer_profile(customer_id):
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    
    cursor.execute('SELECT * FROM customers WHERE id = %s', (customer_id,))
    customer = cursor.fetchone()
    
    cursor.execute('''
        SELECT * FROM jobs 
        WHERE customer_id = %s 
        ORDER BY job_number DESC
    ''', (customer_id,))
    jobs = cursor.fetchall()
    
    cursor.execute('''
        SELECT paper_stock, COUNT(paper_stock) as count 
        FROM jobs 
        WHERE customer_id = %s AND paper_stock != '' AND paper_stock IS NOT NULL
        GROUP BY paper_stock 
        ORDER BY count DESC 
        LIMIT 3
    ''', (customer_id,))
    top_stocks = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    if customer is None:
        return "<script>window.location.href='/customers';</script>"
        
    return render_template('customer_profile.html', customer=customer, jobs=jobs, top_stocks=top_stocks)


# --- Route 8: Live-Save Notes ---
@app.route('/update_notes', methods=['POST'])
def update_notes():
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'error': 'No data received'}), 400
        
    customer_id = data.get('customer_id')
    notes = data.get('notes')

    if not customer_id:
        return jsonify({'success': False, 'error': 'Missing customer ID'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('UPDATE customers SET notes = %s WHERE id = %s', (notes, customer_id))
        success = True
    except Exception as e:
        success = False
        print(f"Database error on notes update: {e}")
    finally:
        cursor.close()
        conn.close()

    return jsonify({'success': success})

# --- Route 9: Edit Existing Customer ---
@app.route('/edit_customer', methods=['POST'])
def edit_customer():
    data = request.get_json()
    customer_id = data.get('customer_id')
    
    if not customer_id:
        return jsonify({'success': False, 'error': 'Customer ID missing.'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute('''
            UPDATE customers SET 
                company_name = %s, contact_name = %s, primary_job_title = %s, email = %s, primary_phone = %s,
                secondary_contact_name = %s, secondary_job_title = %s, secondary_email = %s, secondary_phone = %s
            WHERE id = %s
        ''', (
            data.get('company_name'), data.get('contact_name'), data.get('primary_job_title'), 
            data.get('email'), data.get('primary_phone'), data.get('secondary_contact_name'), 
            data.get('secondary_job_title'), data.get('secondary_email'), data.get('secondary_phone'), 
            customer_id
        ))
        success = True
    except Exception as e:
        success = False
        print(f"Database error: {e}")
    finally:
        cursor.close()
        conn.close()

    return jsonify({'success': success})

# --- Route 10: Job Archive Page ---
@app.route('/job_archive')
def job_archive():
    conn = get_db_connection()
    cursor = conn.cursor(cursor_factory=RealDictCursor)
    
    cursor.execute('''
        SELECT jobs.*, customers.company_name 
        FROM jobs 
        LEFT JOIN customers ON jobs.customer_id = customers.id
        WHERE jobs.current_stage = 'paid'
        ORDER BY job_number DESC
    ''')
    jobs = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template('job_archive.html', jobs=jobs)

# --- Route 11: Return Jobs to Pipeline ---
@app.route('/return_to_pipeline', methods=['POST'])
def return_to_pipeline():
    data = request.get_json()
    job_numbers = data.get('job_numbers', [])

    if not job_numbers:
        return jsonify({'success': False, 'error': 'No jobs selected.'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        for job_num in job_numbers:
            cursor.execute('''
                UPDATE jobs SET current_stage = 'booked in' WHERE job_number = %s
            ''', (job_num,))
            cursor.execute('''
                INSERT INTO status_logs (job_number, stage) VALUES (%s, 'booked in')
            ''', (job_num,))
            
        success = True
    except Exception as e:
        success = False
        print(f"Database error: {e}")
    finally:
        cursor.close()
        conn.close()

    return jsonify({'success': success})

# --- Route 12: Delete a Customer ---
@app.route('/delete_customer/<int:customer_id>', methods=['DELETE'])
def delete_customer(customer_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # Safely unlink this customer's existing jobs so they stay on the board
        cursor.execute('UPDATE jobs SET customer_id = NULL WHERE customer_id = %s', (customer_id,))
        # Delete the customer profile
        cursor.execute('DELETE FROM customers WHERE id = %s', (customer_id,))
        success = True
    except Exception as e:
        success = False
        print(f"Database error on delete: {e}")
    finally:
        cursor.close()
        conn.close()

    return jsonify({'success': success})


def open_browser():
    os.system("open http://127.0.0.1:5002")

if __name__ == '__main__':
    multiprocessing.freeze_support()
    Timer(1, open_browser).start()
    # Host is set to 0.0.0.0 to allow network/Tailscale access
    app.run(host='0.0.0.0', debug=False, port=5002, use_reloader=False)